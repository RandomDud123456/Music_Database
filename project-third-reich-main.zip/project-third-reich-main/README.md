[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/uO3FBJhb)
In the git repository the html names correspond to the required pages.
the home page is home.html and the css page for it is homestyle.css
the about page is about.html and the css page for it aboutstyle.css
the artist page is artist.html and the css page is button.css
the albums page is separate for each artist and correspond to the names of the artists.
each album page contains five albums of the respective artist
each album page is of the format "artist name".html
each song page is of the name format songs-"artist name"-"album name".html and links to five songs of the albums
there is a constant footer present across the webpages


Start at the home page which has links to top artists and top albums.
there is a universally present navigation bar which has links to Home, Artists and About
the Artists page has a single artist per slide and the left and right arrow keys are used to move through the slides
each slide has a black button with the artist name which links to the albums page


