except the about page, all other pages work on different browsers
assumption 1: about.html page is chrome exclusive